// Integrantes da Equipe:
// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos

programa {
  funcao inicio() {
    // Declara variáveis: idade lida, soma (acumulador) e contador de loops
    // Soma e contador iniciam em zero obrigatoriamente
    inteiro idade, soma = 0, contador = 0
    real media

    // Pede a primeira idade para inicializar o processo
    escreva("Insira uma idade (ou digite 0 para encerrar): ")
    leia(idade)

    // O laço vai continuar rodando enquanto a idade for diferente de 0
    enquanto (idade != 0){
      
      // Adiciona a idade digitada ao montante total acumulado
      soma = soma + idade
      
      // Conta que mais uma pessoa válida foi registrada
      contador = contador + 1
      
      // Pede a próxima idade. Se for 0, o laço será quebrado na próxima volta
      escreva("Insira a próxima idade (ou digite 0 para encerrar): ")
      leia(idade)
    }

    // Após sair do laço (quando digitar 0), verifica se alguém foi registrado
    // Isso evita o erro matemático de "divisão por zero"
    se (contador > 0) {
      
      // Calcula a média dividindo a soma de idades pelo número de pessoas
      media = soma / contador
      escreva("O resultado da média das idades é: ", media)
      
    } senao {
      // Caso o usuário digite 0 logo de cara
      escreva("Nenhuma idade válida foi informada.")
    }
  }
}