// Integrantes da Equipe:
// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos

programa {
  funcao inicio() {
    // Declaração das variáveis do tipo real para permitir médias exatas
    real q_atual, q_max, q_min, q_media

    // Lê a quantidade que o produto possui fisicamente na loja agora
    escreva("Digite a quantidade atual em estoque: ")
    leia(q_atual)

    // Lê a capacidade máxima que a loja suporta desse produto
    escreva("Digite a quantidade máxima em estoque: ")
    leia(q_max)

    // Lê a quantidade mínima aceitável antes de faltar o produto
    escreva("Digite a quantidade mínima em estoque: ")
    leia(q_min)

    // Calcula a quantidade média de segurança do estoque
    q_media = (q_max + q_min) / 2.0

    // Exibe qual é a média de segurança para o usuário saber
    escreva("Quantidade Média de segurança: ", q_media, "\n")

    // Estrutura de decisão para verificar se precisa repor o produto
    // Se o que temos (atual) é igual ou maior que a segurança (média), não compra
    se(q_atual >= q_media){
      escreva("Não efetuar compra")
    } 
    // Se o que temos for menor que a média de segurança, repõe o estoque
    senao {
      escreva("Efetuar compra")
    }
  }
}