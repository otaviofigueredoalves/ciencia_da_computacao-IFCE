// Integrantes da Equipe:
// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos

programa {
  funcao inicio() {
    // Declaração das variáveis: inteira para a conta, real para valores financeiros
    inteiro numero_conta 
    real saldo, valor_debito, valor_credito, saldo_atual 

    // Solicita e lê o número da conta do cliente
    escreva("Digite o número da conta (Ex: 2001): ") 
    leia(numero_conta) 

    // Solicita e lê o valor de débito (o que vai sair da conta)
    escreva("Digite o valor de débito disponível: ") 
    leia(valor_debito) 

    // Solicita e lê o valor de crédito (o que vai entrar na conta)
    escreva("Digite o valor de crédito disponível: ") 
    leia(valor_credito) 

    // Solicita e lê o saldo base da conta
    escreva("Digite o saldo inicial: ") 
    leia(saldo) 

    // Realiza o cálculo do saldo atual usando a fórmula do enunciado
    saldo_atual = saldo - valor_debito + valor_credito 

    // Exibe o extrato na tela com os dados formatados
    escreva("==================\n") 
    escreva("CONTA BANCO MASTER\n") 
    escreva("==================\n") 
    escreva("NUMERO CONTA: ",numero_conta, "\n") 
    escreva("DÉBITO: ",valor_debito, "\n") 
    escreva("CRÉDITO: ",valor_credito, "\n") 
    escreva("SALDO ATUAL: ",saldo_atual, "\n") 

    // Avalia a condição financeira do cliente
    // Se o saldo calculado for maior ou igual a zero, exibe "POSITIVO"
    se(saldo_atual >= 0){  
      escreva("SALDO POSITIVO") 
    } 
    // Se a condição acima for falsa (menor que zero), exibe "NEGATIVO"
    senao { 
      escreva("SALDO NEGATIVO") 
    }
  }
}