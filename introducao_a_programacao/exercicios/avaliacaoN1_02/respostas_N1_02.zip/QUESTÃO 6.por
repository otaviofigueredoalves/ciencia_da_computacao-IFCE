// Integrantes da Equipe:
// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos

programa {
  funcao inicio() {
    // n: quantidade de primos desejada pelo usuário
    // contador: controla quantos primos já foram impressos na tela
    // auxiliar: o número atual que o computador está julgando se é primo ou não
    // cont: a quantidade de divisores exatos que o 'auxiliar' tem
    inteiro n, contador, auxiliar, cont, i
    
    // Iniciamos o contador em 1, pois vamos buscar do 1º até o n-ésimo primo
    contador = 1
    
    // O menor e primeiro número primo matemático é o 2, então começamos por ele
    auxiliar = 2
    
    escreva("Digite a quantidade de números primos que deseja ver: ")
    leia(n)

    // O laço vai continuar rodando ENQUANTO não acharmos a meta (n) de primos
    enquanto(contador <= n){
      
      // Zera o número de divisores toda vez que for julgar um novo 'auxiliar'
      cont = 0
      
      // O 'i' (divisor) começa em 1 e vai até o próprio número ('auxiliar')
      para(i = 1; i <= auxiliar; i = i + 1){
        
        // Verifica se a divisão foi exata
        se(auxiliar % i == 0){
          // Se dividiu perfeito, achamos um divisor! Soma 1 no 'cont'
          cont = cont + 1
        }
      }
      
      // Conclusão: Se o 'auxiliar' teve EXATAMENTE 2 divisores (o 1 e ele mesmo)...
      se(cont == 2){
        escreva(auxiliar, " ") // Ele é primo! Imprime na tela
        
        // Como achamos um primo, somamos 1 ao contador de sucesso
        // Isso DEVE ficar aqui dentro, só sobe o placar se achar o primo
        contador = contador + 1
      }
      
      // Independentemente de ser primo ou não, aumenta o 'auxiliar' em 1 
      // para que na próxima rodada do 'enquanto' ele julgue o próximo número
      auxiliar = auxiliar + 1                                                                                                  
    }
  }
}