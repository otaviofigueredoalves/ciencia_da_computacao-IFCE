// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos
programa {
  funcao inicio() {
    // 3. Escreva um algoritmo que leia três valores inteiros e mostre-os em ordem crescente. [2pts] 
    // =======================
    // PERMUTAÇÕES POSSÍVEIS
    // =======================
    // num1 > num2 > num3
    // num1 > num3 > num2
    // num2 > num1 > num3
    // num2 > num3 > num1
    // num3 > num1 > num2
    // num3 > num2 > num1
    inteiro num1, num2, num3

    escreva("Escreva o primeiro número: ") // imprime texto na tela
    leia(num1) // num1 recebe o valor que o usuário fornece
    escreva("Escreva o primeiro número: ") // imprime texto na tela
    leia(num2) // num2 recebe o valor que o usuário fornece
    escreva("Escreva o primeiro número: ") // imprime texto na tela
    leia(num3) // num3 recebe o valor que o usuário fornece

    se(num1 >= num2 e num2 >= num3){ // se num1 for maior que num2 e num2 maior que num3, a condição é satisfeita e executa o código abaixo
      escreva(num3,',',num2,',',num1) // imprime na tela do menor pro maior, baseado na verificação da condição
    }
    senao se(num1 >= num3 e num3 >= num2){ // se num1 for maior que num3 e num3 maior que num2, a condição é satisfeita e executa o código abaixo
      escreva(num2,',',num3,',',num1) // imprime na tela do menor pro maior, baseado na verificação da condição

    } senao se(num2 >= num1 e num1 >= num3){ // se num2 for maior que num1 e num1 maior que num3, a condição é satisfeita e executa o código abaixo
      escreva(num3,',',num1,',',num2) // imprime na tela do menor pro maior, baseado na verificação da condição

    } senao se(num2 >= num3 e num3 >= num1){ // se num2 for maior que num3 e num3 maior que num1, a condição é satisfeita e executa o código abaixo
      escreva(num1,',',num3,',',num2) // imprime na tela do menor pro maior, baseado na verificação da condição

    } senao se(num3 >= num1 e num1 >= num2){ // se num3 for maior que num1 e num1 maior que num2, a condição é satisfeita e executa o código abaixo
      escreva(num2,',',num1,',',num3) // imprime na tela do menor pro maior, baseado na verificação da condição
      
    } senao { // se nenhuma condição for satisfeita, execute a última possibilidade lógica da permutação
      escreva(num1,',',num2,',',num3) // imprime na tela do menor pro maior, baseado na verificação da condição
    }
  }
}
