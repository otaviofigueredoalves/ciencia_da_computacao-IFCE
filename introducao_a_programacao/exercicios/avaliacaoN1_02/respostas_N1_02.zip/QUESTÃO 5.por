// Integrantes da Equipe:
// Otávio Figueredo Alves
// César de Araújo Oliveira
// João Pedro Martins dos Santos

programa {
  funcao inicio() {
    // Declara 'num' (alvo), 'div' (tentativa de divisão), e 'cont' (quantos dividiram)
    inteiro num, div, cont = 0

    // Recebe o número alvo do usuário
    escreva("Digite um número para verificar se é primo: ")
    leia(num)

    // Laço que testa divisores começando de 1 até o próprio número alvo
    para(div = 1; div <= num ; div++){

      // Verifica se a divisão foi exata (resto igual a zero)
      se(num % div == 0){
        // Se for divisor válido, aumenta o contador
        cont = cont + 1
      }

      // Otimização: Se já encontrou 3 ou mais divisores, não tem como ser primo
      se(cont > 2){
        escreva("O número NÃO é primo")
        
        // Comando 'pare' interrompe o laço para não gastar processamento à toa
        pare
      }
    }

    // Após terminar de testar todos os números
    // Se encontrou EXATAMENTE 2 divisores (1 e ele mesmo), então é primo
    se(cont == 2){
      escreva("O número é primo")
    }
    // Tratando a regra de exceção do enunciado (o número 1 não é primo)
    senao se (num == 1) { 
      escreva("O número NÃO é primo")
    }
  }
}